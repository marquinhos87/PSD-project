#!/bin/sh
../rebar3 compile
